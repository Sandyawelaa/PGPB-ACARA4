package com.example.activityintent;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    private TextView tvUsername;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvUsername = findViewById(R.id.tvRegister);

        // Get the username from the intent
        String username = getIntent().getStringExtra("USERNAME_KEY"); // Make sure the key matches

        // Set the username in the TextView
        if (username != null) {
            tvUsername.setText("Hello, " + username + "!");
        }
    }
}
