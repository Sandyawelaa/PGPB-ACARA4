package com.example.activityintent;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {

    private EditText usernameEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        usernameEditText = findViewById(R.id.etUsername);
        Button registerButton = findViewById(R.id.btnRegister);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the entered username during registration
                String username = usernameEditText.getText().toString();

                // Store the username and pass it to HomeActivity
                goToHomeActivity(username); // Pass the username to HomeActivity
            }
        });

        // "Already Have an Account? Log in" TextView click listener
        findViewById(R.id.registerText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Go back to MainActivity (login screen)
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    // Function to navigate to HomeActivity with the username
    private void goToHomeActivity(String username) {
        Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
        intent.putExtra("USERNAME_KEY", username); // Pass the username
        startActivity(intent); // Start HomeActivity
    }
}
