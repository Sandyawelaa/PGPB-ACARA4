package com.example.activityintent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private String registeredUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.etUsername);
        passwordEditText = findViewById(R.id.etPassword);
        Button loginButton = findViewById(R.id.btnLogin);
        TextView registerText = findViewById(R.id.registerText);

        // Retrieve the username passed from the registration activity
        Intent intent = getIntent();
        registeredUsername = intent.getStringExtra("USERNAME_KEY");

        // Login button click listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();

                // Simulate login check (you can add actual validation here)
                if (enteredUsername.equals(registeredUsername)) {
                    // If login is successful, display the welcome message
                    Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                    intent.putExtra("USERNAME_KEY", registeredUsername); // Pass the username to the next activity
                    startActivity(intent);
                } else {
                    // Handle invalid login (show a Toast message)
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Register text click listener (optional)
        registerText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
